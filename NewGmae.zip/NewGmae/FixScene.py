import cocos
import cocos.tiles

class FixScene(cocos.scene.Scene):
    def __init__(self):
        super(FixScene, self).__init__()
        self.back_ground_map1 = cocos.tiles.load('img/3Jaguars.tmx')
        self.back1_bg0 = self.back_ground_map1['Tile Layer 1']
        self.back1_bg1 = self.back_ground_map1['Tile Layer 2']
        self.back1_bg2 = self.back_ground_map1['Tile Layer 3']
        self.back1_bg0.set_view(0,0,self.back1_bg0.px_width, self.back1_bg0.px_height)
        self.back1_bg1.set_view(0,0,self.back1_bg1.px_width, self.back1_bg1.px_height)
        self.back1_bg2.set_view(0,0,self.back1_bg2.px_width, self.back1_bg2.px_height)
    
    def fix(self, level):
        if(level ==1):
            self.add(self.back1_bg0, z=0)
            self.add(self.back1_bg1, z=1)
            self.add(self.back1_bg2, z=2)