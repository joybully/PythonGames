<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="TIleset_1" tilewidth="32" tileheight="32" tilecount="848" columns="8">
 <image source="jungle-ruins_v3-1.png" width="256" height="3392"/>
</tileset>
