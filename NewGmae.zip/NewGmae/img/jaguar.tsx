<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="jaguar" tilewidth="32" tileheight="32" tilecount="1760" columns="44">
 <image source="jaguar-statue.png" width="1408" height="1280"/>
</tileset>
