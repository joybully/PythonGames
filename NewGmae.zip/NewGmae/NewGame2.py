import random
from collections import defaultdict

from pyglet.image import load, ImageGrid, Animation
from pyglet.window import key

import cocos
import cocos.collision_model as cm
import cocos.euclid as eu
import cocos.particle_systems as ps

import pygame
import pygame.mixer

import cocos.tiles
import cocos.actions as ac

from cocos.director import director

import pyglet.font
import pyglet.resource

from FixScene import FixScene
# pygame.mixer.init()
# Shooting_Sound = pygame.mixer.Sound('Arcade_Shoot.wav')
# Kill_Alien = pygame.mixer.Sound('coin1.wav')
# Alien_Shot = pygame.mixer.Sound('Shoot01.wav')
# Kill_Ship = pygame.mixer.Sound('Ship_Drop.mp3')
# Game_BGM = pygame.mixer.Sound('Cocos2d.Invader_BGM.wav')

# Game_BGM.play(-1)

class Actor(cocos.sprite.Sprite):
    def __init__(self, image, x, y):
        super(Actor, self).__init__(image)
        self.position = eu.Vector2(x, y)
        self.cshape = cm.AARectShape(self.position,
                                     self.width * 0.5,
                                     self.height * 0.5)

    def move(self, offset):
        self.position += offset
        self.cshape.center += offset

    def update(self, elapsed):
        pass

    def collide(self, other):
        pass

class PlayerCannon(Actor):
    
    KEYS_PRESSED = defaultdict(int)
    def __init__(self, x, y):
        super(PlayerCannon, self).__init__('img/playerball2.png', x, y)
        self.speedRL = eu.Vector2(200,0)
        self.speedUD = eu.Vector2(0,-200)
        self.elapsed = 0
        self.period = 0.3

    def update(self, elapsed):
        pressed = PlayerCannon.KEYS_PRESSED
        space_pressed = pressed[key.SPACE] == 1
        if(self.elapsed >=0):
            self.elapsed -= elapsed
        if space_pressed and self.elapsed<0:
            PlayerShoot.SHOOT+=1
            if(PlayerShoot.SHOOTDIRECTION == 'U'):
                j = PlayerShoot(self.x, self.y + 50,'img/laser3.png')
            elif(PlayerShoot.SHOOTDIRECTION == 'D'):
                j = PlayerShoot(self.x, self.y - 50,'img/laser3.png')
            elif(PlayerShoot.SHOOTDIRECTION == 'R'):
                j = PlayerShoot(self.x+50, self.y,'img/laser4.png')
            elif(PlayerShoot.SHOOTDIRECTION == 'L'):
                j = PlayerShoot(self.x-50, self.y,'img/laser4.png')
            self.parent.add(j)
            GameLayer.INSTANCE_LIST.append(j)
            #Shooting_Sound.play()
            self.elapsed+=self.period
        movementRL = 0
        movementUD = 0
        movementRL = pressed[key.RIGHT] - pressed[key.LEFT]
        if (movementRL>0):
            PlayerShoot.SHOOTDIRECTION = 'L'
        elif(movementRL<0):
            PlayerShoot.SHOOTDIRECTION = 'R'
        w = self.width * 0.5
        k = self.x
        g = self.speedRL.x
        k +=  g*movementRL * elapsed
        if movementRL!=0 and w <= k and k <= self.parent.width - w and movementUD==0:
            self.move(self.speedRL * movementRL * elapsed)
        movementUD = pressed[key.DOWN]-pressed[key.UP]
        if (movementUD>0):
            PlayerShoot.SHOOTDIRECTION = 'U'
        elif(movementUD<0):
            PlayerShoot.SHOOTDIRECTION = 'D'
        h = self.height * 0.5
        j = self.y
        g = self.speedUD.y
        j +=  g*movementUD * elapsed
        if movementUD!=0 and h <= j and j <= self.parent.height - h and movementRL==0:
            self.move(self.speedUD * movementUD * elapsed)
            
    def playercannon_position(self):
        return self.position

    def collide_enemy(self, other):
        try:
            other.kill()
        except:
            print("no child")
        self.kill()
        #Kill_Ship.play()
    def collide_liveitem(self,other):
        other.updatelives()

class GameLayer(cocos.layer.Layer):
    INSTANCE_LIST = []
    ENEMYSEEKLIST = []
    is_event_handler = True

    def on_key_press(self, k, _):
        PlayerCannon.KEYS_PRESSED[k] = 1

    def on_key_release(self, k, _):
        PlayerCannon.KEYS_PRESSED[k] = 0
    
    def __init__(self, hud):
        super(GameLayer, self).__init__()
        w, h = cocos.director.director.get_window_size()
        self.hud = hud
        self.width = w
        self.height = h
        self.lives = 100
        self.score = 0
        self.level = 1
        self.elapsed_time1 = 0
        self.elapsed_time2 = 0
        self.update_score()
        self.update_lives()
        self.create_player()
        #self.create_alien_group(100, 300)
        cell = 1.25 * 50
        self.collman = cm.CollisionManagerGrid(0, w, 0, h, 
                                               cell, cell)
        self.schedule(self.update)
        self.period = 2
        self.elapsed = 0
        self.timerecord = 0
        self.enemy1_width =0
        self.non_collide = True
        self.elapsed_collide = 0

    def create_player(self):
        self.player = PlayerCannon(self.width * 0.5, self.height*0.5)
        self.add(self.player)
        self.hud.update_lives(self.lives)


    def update_score(self, score=0):
        self.score += score
        self.hud.update_score(self.score)
        self.hud.update_level(self.level)
        # if(self.score>90):
        #     GameLayer.INSTANCE_LIST = []
        #     for alien in self.alien_group:
        #         if(alien!=None):
        #             alien.kill()
            
    def update_lives(self, lives=0):
        self.lives += lives
        self.hud.update_lives(self.lives)

    # def create_alien_group(self, x, y):
    #     alien = Alien1('img/ball04.png',50,self.height-100, 100,eu.Vector2(100,0),100)
    #     if(self.level == 1):
    #         for i in range(5):
    #             self.add(alien)

    def create_enemy(self, time1, time2):
        self.elapsed += (time1-self.timerecord)
        self.timerecord = time1
        if(self.level == 1 and time1-time2>3 and self.elapsed>self.period):
            if random.random()<0.02:
                wid = random.randint(0,self.width)
                hei = random.randint(0,self.height)
                life = LiveItem('img/playerball2.png', wid, hei, 1)
                self.add(life)
            if random.random()<0.02:
                life = LiveItem('img/playerball2.png', 300, 300, 1)
                self.add(life)
            if random.random()<0.02:
                #img, x, y, score, health
                enemy_seek = EnemySeek('img/ball04.png', self.width, self.height,50,50)
                x, y = self.player.position
                enemy_seek.target = eu.Vector2(x,y)
                self.ENEMYSEEKLIST.append(enemy_seek)
                # self.enemy_seek.append(EnemySeek(self.width, 0))
                self.add(enemy_seek)
            if random.random()<0.02:
                #img, x, y, score, health
                enemy_seek = EnemySeek('img/ball04.png', 0, self.height,50,50)
                x, y = self.player.position
                enemy_seek.target = eu.Vector2(x,y)
                self.ENEMYSEEKLIST.append(enemy_seek)
                # self.enemy_seek.append(EnemySeek(self.width, 0))
                self.add(enemy_seek)
            if random.random()<0.02:
                #img, x, y, score, health
                enemy_seek = EnemySeek('img/ball04.png', self.width, 0,50,50)
                x, y = self.player.position
                enemy_seek.target = eu.Vector2(x,y)
                self.ENEMYSEEKLIST.append(enemy_seek)
                # self.enemy_seek.append(EnemySeek(self.width, 0))
                self.add(enemy_seek)
            if random.random()<0.02:
                #img, x, y, score, health
                enemy_seek = EnemySeek('img/ball04.png', 0, 0,50,50)
                x, y = self.player.position
                enemy_seek.target = eu.Vector2(x,y)
                self.ENEMYSEEKLIST.append(enemy_seek)
                # self.enemy_seek.append(EnemySeek(self.width, 0))
                self.add(enemy_seek)
        if(self.level == 2 and time1-time2>7):
            if random.randint()<0.1:
                wid = random.randint(0,self.width)
                hei = random.randint(0,self.height)
                life = LiveItem('img/playerball2.png', wid, hei, 1)
                self.add(life)
            if random.random()<0.05:
                width = random.randrange(0,self.width)
                #img,width,height,score,speed,health
                enemyup = Enemy1('img/ball04.png',width,self.height,50,eu.Vector2(0,-100),50)
                self.add(enemyup)
            if random.random()<0.05:
                width = random.randrange(0,self.width)
                enemydown = Enemy1('img/ball04.png',width,self.height-512,50,eu.Vector2(0,100),50)
                self.add(enemydown)
            if random.random()<0.05:
                height = random.randrange(0,self.height)
                enemyleft = Enemy1('img/ball04.png',self.width,height,50,eu.Vector2(-100,0),50)
                self.add(enemyleft)
            if random.random()<0.05:
                height = random.randrange(0,self.height)
                enemyright = Enemy1('img/ball04.png',self.width-960,height,50,eu.Vector2(100,0),50)
                self.add(enemyright)
        if(self.level == 3 and time1-time2>7 and self.elapsed>self.period):
            self.elapsed = (self.elapsed%self.period)
            width = self.enemy1_width
            width2 = (self.enemy1_width+480)%self.width
            width3 = (self.enemy1_width+640)%self.width
            self.enemy1_width+=60
            if(self.enemy1_width>self.width):
                self.enemy1_width-=self.width
            height = (width/self.width)*self.height
            e1_vec = eu.Vector2(self.width-2*width,-self.height).normalize()
            e3_vec = eu.Vector2(self.width, self.height-2*height).normalize()
            enemy1 = Enemy1('img/ball04.png',width,self.height,50,100*e1_vec,50)#work
            enemy2 = Enemy1('img/ball04.png',self.width-width,0,50,-100*e1_vec,50)
            enemy3 = Enemy1('img/ball04.png',0,height,50,100*e3_vec,50)#work
            enemy4 = Enemy1('img/ball04.png',self.width,self.height-height,50,-100*e3_vec,50)
            self.add(enemy1)
            self.add(enemy2)
            self.add(enemy3)
            self.add(enemy4)
            #img, x, y, lives
            height2 = (width2/self.width)*self.height
            e1_vec = eu.Vector2(self.width-2*width2,-self.height).normalize()
            e3_vec = eu.Vector2(self.width, self.height-2*height2).normalize()
            enemy1 = Enemy1('img/ball04.png',width2,self.height,50,100*e1_vec,50)#work
            enemy2 = Enemy1('img/ball04.png',self.width-width2,0,50,-100*e1_vec,50)
            enemy3 = Enemy1('img/ball04.png',0,height2,50,100*e3_vec,50)#work
            enemy4 = Enemy1('img/ball04.png',self.width,self.height-height2,50,-100*e3_vec,50)
            self.add(enemy1)
            self.add(enemy2)
            self.add(enemy3)
            self.add(enemy4)
            # height3 = (width3/self.width)*self.height
            # e1_vec = eu.Vector2(self.width-2*width3,-self.height).normalize()
            # e3_vec = eu.Vector2(self.width, self.height-2*height3).normalize()
            # enemy1 = Enemy1('img/ball04.png',width3,self.height,50,100*e1_vec,50)#work
            # enemy2 = Enemy1('img/ball04.png',self.width-width3,0,50,-100*e1_vec,50)
            # enemy3 = Enemy1('img/ball04.png',0,height3,50,100*e3_vec,50)#work
            # enemy4 = Enemy1('img/ball04.png',self.width,self.height-height3,50,-100*e3_vec,50)
            # self.add(enemy1)
            # self.add(enemy2)
            # self.add(enemy3)
            # self.add(enemy4)

    def update(self, dt):
        self.collman.clear()
        for _, node in self.children:
            self.collman.add(node)
            if not self.collman.knows(node):
                self.remove(node)

        #총알 충돌
        for i in GameLayer.INSTANCE_LIST:
            self.collide(i)

        for enemy in self.ENEMYSEEKLIST:
            enemy.target = self.player.position

        if not self.non_collide:
            self.elapsed_collide +=dt
            if(self.elapsed_collide>5):
                self.non_collide = True

        #플레이어 충돌
        if (self.non_collide and self.collide(self.player) == "enemy"):
            self.respawn_player()
            self.non_collide = False
            self.elapsed_collide = 0

        # for column in self.alien_group.columns:
        #     shoot = column.shoot()
        #     if shoot is not None:
        #         self.add(shoot)

        for _, node in self.children:
            node.update(dt)
        #self.alien_group.update(dt)
        # if random.random() < 0.01:
        #     self.add(MysteryShip(50, self.height - 50))
        
        self.elapsed_time1 += dt
        # print(self.elapsed_time1)
        # print(self.elapsed_time2)
        self.create_enemy(self.elapsed_time1, self.elapsed_time2)
        if(self.score>10000 and self.level == 1):
            self.level = 2
            self.hud.show_level_up()
            self.elapsed_time2 = self.elapsed_time1
        elif(self.level==2):
            if(self.elapsed_time1-self.elapsed_time2>7 and self.elapsed_time2!=0):
                self.elapsed_time2 = 0
                self.hud.remove_level_up()
            elif(self.score>600):
                self.level = 3
                self.hud.show_level_up()
                self.elapsed_time2 = self.elapsed_time1
        elif(self.level==3):
            if(self.elapsed_time1-self.elapsed_time2>7 and self.elapsed_time2!=0):
                self.elapsed_time2 = 0
                self.hud.remove_level_up()
            elif(self.score>1200):
                self.level = 'clear'
                self.unschedule(self.update)
                self.hud.remove_level_up()
                self.hud.show_game_clear()
            


    def collide(self, node):
        if node is not None:
            for other in self.collman.iter_colliding(node):
                if(type(other) is LiveItem and type(node) is PlayerCannon):
                    node.collide_liveitem(other)
                    return "item"
                elif(type(node) is PlayerShoot):
                    node.collide(other)
                else:
                    node.collide_enemy(other)
                    return "enemy"
        return False
    
    def respawn_player(self):
        self.lives -= 1
        if self.lives < 0:
            self.unschedule(self.update)
            self.hud.remove_level_up()
            self.hud.show_game_over()
        else:
            self.create_player()

class Item(Actor):
    def __init__(self, img, x, y):
        super(Item, self).__init__(img, x, y)
        self.speed = eu.Vector2(0,0)
        
    def on_exit(self):
        super(Item, self).on_exit()

class LiveItem(Item):
    def __init__(self, img, x, y, lives):
        super(LiveItem, self).__init__(img, x, y)
        self.lives = lives

    def updatelives(self):
        self.parent.update_lives(self.lives)            
        self.kill()

class Enemy(Actor):
    def __init__(self, img, x, y, score):
        super(Enemy, self).__init__(img , x, y)
        self.speed = eu.Vector2(100, 0)
        #self.score = score
        #self.column = column
        self.score = score

    def on_exit(self):
        super(Enemy, self).on_exit()

class Enemy1(Enemy):
    def __init__(self, img, x, y, score, speed,health):
        super(Enemy1, self).__init__(img, x, y, score)
        self.speed = speed
        self.health = health
        self.score = score
    
    def update(self, elapsed):
        self.move(self.speed * elapsed)

    def updateHealth(self):
        self.health -= 50
        if(self.health == 0):
            self.parent.update_score(self.score)            
            self.kill()

def truncate(vector, m):
        magnitude = abs(vector)
        if magnitude > m:
            vector *= m / magnitude
        return vector

class EnemySeek(Enemy):
    def __init__(self, img, x, y, score,health):
        super(EnemySeek, self).__init__(img , x, y, score)
        self.position = (x, y)
        self.velocity = eu.Vector2(0, 0)
        self.speed = 2
        self.max_force = 5
        self.max_velocity = 100
        self.target = None
        self.health = health
        self.schedule(self.update)

    def update(self, dt):
        if self.target is None:
            return
        distance = self.target - eu.Vector2(self.x, self.y)
        steering = distance * self.speed - self.velocity
        steering = truncate(steering, self.max_force)
        self.velocity = truncate(self.velocity + steering, 
                                 self.max_velocity)
        self.move(self.velocity * dt)

    def updateHealth(self):
        self.health -= 50
        if(self.health == 0):
            self.parent.update_score(self.score)            
            self.kill()
            return 30
# class MysteryShip(Enemy):
#     SCORES = [10, 50, 100, 200]

#     def __init__(self, x, y):
#         score = random.choice(MysteryShip.SCORES)
#         super(MysteryShip, self).__init__('img/alien4.png', x, y, 
#                                           score)
#         self.speed = eu.Vector2(150, 0)
#         self.score = score

#     def update(self, elapsed):
#         self.move(self.speed * elapsed)
    
#     def updateHealth(self):
#         self.parent.update_score(self.score)
#         self.kill()

class Shoot(Actor):
    def __init__(self, x, y, img='img/shoot.png'):
        super(Shoot, self).__init__(img, x, y)
        self.speed = eu.Vector2(0, -400)
        
    def update(self, elapsed):
        self.move(self.speed * elapsed)

class PlayerShoot(Shoot):
    SHOOT = 0
    SHOOTDIRECTION = 'U'
    def __init__(self, x, y, img):
        super(PlayerShoot, self).__init__(x, y, img)
        if(self.SHOOTDIRECTION == 'U'):
            self.speed = eu.Vector2(0, 400)
        elif(self.SHOOTDIRECTION == 'D'):
            self.speed = eu.Vector2(0, -400)
        elif(self.SHOOTDIRECTION == 'R'):
            self.speed = eu.Vector2(400, 0)
        elif(self.SHOOTDIRECTION == 'L'):
            self.speed = eu.Vector2(-400, 0) 

    def collide(self, other):
        if isinstance(other, Enemy):
            other2 = other
            if(other.updateHealth()==30):
                if other in GameLayer.ENEMYSEEKLIST:
                    GameLayer.ENEMYSEEKLIST.remove(other2)
            #Kill_Alien.play()
            PlayerShoot.SHOOT -=1
            if(self in GameLayer.INSTANCE_LIST):
                GameLayer.INSTANCE_LIST.remove(self)
                try:
                    self.kill()
                except:
                    print("childnotfound")

    def on_exit(self):
        super(PlayerShoot, self).on_exit()
        #self.kill()

class HUD(cocos.layer.Layer):
    def __init__(self):
        super(HUD, self).__init__()
        w, h = cocos.director.director.get_window_size()
        self.score_text = cocos.text.Label('', font_size=18)
        self.score_text.position = (20, h - 40)
        self.lives_text = cocos.text.Label('', font_size=18)
        self.lives_text.position = (w - 100, h - 40)
        self.level_text = cocos.text.Label('', font_size=18)
        self.level_text.position = (w - 100, h - 80)
        self.level_up = cocos.text.Label('Level Up', font_size=50,
                                     anchor_x='center',
                                     anchor_y='center')
        self.add(self.score_text)
        self.add(self.lives_text)
        self.add(self.level_text)

    def update_score(self, score):
        self.score_text.element.text = 'Score: %s' % score

    def update_lives(self, lives):
        self.lives_text.element.text = 'Lives: %s' % lives

    def update_level(self, level):
        self.level_text.element.text = 'Level: %s' % level

    def show_level_up(self):
        w, h = cocos.director.director.get_window_size()
        self.level_up.position = w * 0.5, h * 0.5
        #pygame.mixer.stop()
        self.add(self.level_up)

    def remove_level_up(self):
        if self.level_up in self:
            self.remove(self.level_up)

    def show_game_clear(self):
        w, h = cocos.director.director.get_window_size()
        game_clear = cocos.text.Label('Game Clear', font_size=50,
                                     anchor_x='center',
                                     anchor_y='center')
        game_clear.position = w * 0.5, h * 0.5
        #pygame.mixer.stop()
        self.add(game_clear)

    def show_game_over(self):
        w, h = cocos.director.director.get_window_size()
        game_over = cocos.text.Label('Game Over', font_size=50,
                                     anchor_x='center',
                                     anchor_y='center')
        game_over.position = w * 0.5, h * 0.5
        #pygame.mixer.stop()
        self.add(game_over)


if __name__ == '__main__':
    pyglet.resource.path.append('img')
    cocos.director.director.init(caption='Running Ball', 
                                 width=960, height=512)
    main_scene = FixScene()
    hud_layer = HUD()
    main_scene.add(hud_layer, z=4)
    game_layer = GameLayer(hud_layer)
    main_scene.add(game_layer, z=3)
    main_scene.fix(1)
    cocos.director.director.run(main_scene)
